"use strict";
(() => {
  // extensions/mmsu-gradesheet/src/access.ts
  var API_OVERRIDE_KEY = "vantage-api-url";
  var ACCESS_CACHE_MS = 10 * 60 * 1e3;
  async function fetchAccess() {
    const stored = (await chrome?.storage?.local.get(API_OVERRIDE_KEY))?.[API_OVERRIDE_KEY];
    const api = (typeof stored === "string" && stored ? stored : "https://vantage.api.nbericmmsu.com").replace(/\/$/, "");
    const fallbackApp = "";
    try {
      const response = await fetch(`${api}/auth/extension-access/mmsu-grade-push`, { credentials: "include", cache: "no-store" });
      if (!response.ok) return { allowed: false, reason: "unreachable", appUrl: fallbackApp };
      const data = await response.json();
      const appUrl = data.appUrl || fallbackApp;
      if (data.allowed && data.user) return { allowed: true, name: data.user.name, email: data.user.email, appUrl };
      const reason = ["signed_out", "role", "not_granted", "not_enabled"].find((r) => r === data.reason) ?? "unreachable";
      return { allowed: false, reason, name: data.user?.name, email: data.user?.email, appUrl };
    } catch {
      return { allowed: false, reason: "unreachable", appUrl: fallbackApp };
    }
  }

  // extensions/mmsu-gradesheet/src/background.ts
  var GRADESHEETS_URL = "https://my.mmsu.edu.ph/my/class/gradesheet";
  function openGradesheets() {
    void chrome?.tabs?.create({ url: GRADESHEETS_URL });
  }
  chrome?.action?.onClicked.addListener(openGradesheets);
  chrome?.runtime?.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "vantage-check-access") return;
    void fetchAccess().then(sendResponse);
    return true;
  });
  globalThis.vantageOpenGradesheets = openGradesheets;
})();
