"use strict";
(() => {
  // extensions/mmsu-gradesheet/src/access.ts
  var CACHE_KEY = "vantage-mmsu-access";
  var ACCESS_CACHE_MS = 10 * 60 * 1e3;
  async function requestAccess(force = false) {
    if (!force) {
      const cached = (await chrome?.storage?.local.get(CACHE_KEY))?.[CACHE_KEY];
      if (cached?.access?.allowed && Date.now() - cached.at < ACCESS_CACHE_MS) return cached.access;
    }
    let access;
    try {
      access = await chrome?.runtime?.sendMessage({ type: "vantage-check-access" });
      if (!access || typeof access.allowed !== "boolean") throw new Error("no answer");
    } catch {
      access = { allowed: false, reason: "unreachable", appUrl: "" };
    }
    if (access.allowed) await chrome?.storage?.local.set({ [CACHE_KEY]: { at: Date.now(), access } });
    else await chrome?.storage?.local.remove(CACHE_KEY);
    return access;
  }
  function describeDenied(access) {
    switch (access.reason) {
      case "signed_out":
        return { title: "Sign in to Vantage", text: "Sign in to Vantage in this browser, then check again. The grade push only works for people signed in to Vantage." };
      case "not_granted":
        return { title: "No access yet", text: `${access.name ?? "Your account"} has not been given access to MMSU Grade Push. Ask a Vantage administrator to allow it for you (Users, Experimental access).` };
      case "not_enabled":
        return { title: "Turn it on in Vantage", text: "An administrator allowed you to use MMSU Grade Push. Switch it on in your Vantage Profile (Experimental features), then check again." };
      case "role":
        return { title: "Not available for your role", text: "MMSU Grade Push is not available for your Vantage role." };
      default:
        return { title: "Could not reach Vantage", text: "The Vantage server did not answer, so access could not be checked. Check your connection and try again." };
    }
  }

  // extensions/mmsu-gradesheet/src/fill.ts
  function applyChanges(items) {
    let applied = 0;
    const failed = [];
    for (const item of items) {
      const select = item.portal?.select;
      if (!select || item.value === void 0) continue;
      select.value = item.value;
      if (select.value !== item.value) {
        failed.push(item);
        continue;
      }
      select.dispatchEvent(new Event("input", { bubbles: true }));
      select.dispatchEvent(new Event("change", { bubbles: true }));
      applied++;
    }
    return { applied, failed };
  }
  function verifyJob(job, sheet) {
    const byKey = new Map(sheet.rows.map((row) => [row.key, row]));
    const items = job.expected.map((exp) => {
      const row = byKey.get(exp.key);
      if (!row) return { studentNumber: exp.studentNumber, name: exp.name, expected: exp.value, actual: "", status: "missing" };
      return {
        studentNumber: exp.studentNumber,
        name: exp.name,
        expected: exp.value,
        actual: row.current,
        status: row.current === exp.value ? "match" : "differs"
      };
    });
    const promised = new Set(job.expected.map((exp) => exp.key));
    const unexpected = sheet.rows.filter((row) => !promised.has(row.key) && (job.before[row.key] ?? "") !== row.current).map((row) => ({ studentNumber: row.studentNumber, name: row.name, before: job.before[row.key] ?? "", after: row.current }));
    return { items, unexpected, matched: items.filter((item) => item.status === "match").length };
  }

  // extensions/mmsu-gradesheet/src/job.ts
  var AUTO_VERIFY_MS = 2 * 60 * 1e3;
  var JOB_MAX_AGE_MS = 30 * 60 * 1e3;
  var keyFor = (sheetId) => `vantage-mmsu-job-${sheetId}`;
  var hasChromeStorage = () => typeof chrome !== "undefined" && !!chrome?.storage?.local;
  async function saveJob(job) {
    const key = keyFor(job.sheetId);
    if (hasChromeStorage()) await chrome.storage.local.set({ [key]: job });
    else localStorage.setItem(key, JSON.stringify(job));
  }
  async function loadJob(sheetId, now = Date.now()) {
    const key = keyFor(sheetId);
    let job;
    if (hasChromeStorage()) job = (await chrome.storage.local.get(key))[key];
    else {
      const raw = localStorage.getItem(key);
      job = raw ? JSON.parse(raw) : void 0;
    }
    if (!job || now - job.createdAt > JOB_MAX_AGE_MS) {
      if (job) await clearJob(sheetId);
      return null;
    }
    return job;
  }
  async function clearJob(sheetId) {
    const key = keyFor(sheetId);
    if (hasChromeStorage()) await chrome.storage.local.remove(key);
    else localStorage.removeItem(key);
  }

  // extensions/mmsu-gradesheet/src/studentNumber.ts
  function idKey(raw) {
    return raw.toUpperCase().replace(/[^A-Z0-9]/g, "");
  }
  function looksLikeStudentNumber(raw) {
    const text = raw.trim();
    if (text.length === 0 || text.length > 16) return false;
    if (/[A-Za-z]{4,}/.test(text)) return false;
    return text.replace(/\D/g, "").length >= 6;
  }
  function nameWords(name) {
    return name.toUpperCase().replace(/[^\p{L}\s]/gu, " ").split(/\s+/).filter((word) => word.length >= 3);
  }
  function namesDisagree(sourceName, portalName) {
    const source = nameWords(sourceName);
    const portal = new Set(nameWords(portalName));
    if (source.length === 0 || portal.size === 0) return false;
    return !source.some((word) => portal.has(word));
  }

  // extensions/mmsu-gradesheet/src/paste.ts
  function parseDelimited(text) {
    const source = text.replace(/\r\n?/g, "\n");
    const sample = source.split("\n").filter((line) => line.trim() !== "").slice(0, 5).join("\n");
    const count = (char) => sample.split(char).length - 1;
    const delimiter = count("	") > 0 ? "	" : count(";") > count(",") ? ";" : ",";
    const rows = [];
    let row = [];
    let cell = "";
    let quoted = false;
    for (let i = 0; i < source.length; i++) {
      const char = source[i];
      if (quoted) {
        if (char === '"') {
          if (source[i + 1] === '"') {
            cell += '"';
            i++;
          } else quoted = false;
        } else cell += char;
      } else if (char === '"' && cell === "") quoted = true;
      else if (char === delimiter) {
        row.push(cell);
        cell = "";
      } else if (char === "\n") {
        row.push(cell);
        rows.push(row);
        row = [];
        cell = "";
      } else cell += char;
    }
    row.push(cell);
    rows.push(row);
    return rows.map((r) => r.map((c) => c.trim())).filter((r) => r.some((c) => c !== ""));
  }
  var normalize = (text) => text.toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
  var ID_HEADERS = ["student number", "student no", "student id", "id number", "id no", "studentnumber", "studentid", "id"];
  var NAME_HEADERS = ["student name", "full name", "name"];
  var GRADE_HEADERS = ["final grade", "finalgrade", "final rating", "total grade", "grade", "rating"];
  function findColumn(headers, patterns) {
    for (const pattern of patterns) {
      const index = headers.indexOf(pattern);
      if (index >= 0) return index;
    }
    for (const pattern of patterns) {
      if (pattern.length < 5) continue;
      const index = headers.findIndex((header) => header.includes(pattern));
      if (index >= 0) return index;
    }
    return -1;
  }
  var GRADE_LIKE = /^(?:[1-5](?:[.,]\d{1,2})?|INC|DRP|IP|INCOMPLETE|DROPPED)$/i;
  function detectMapping(rows) {
    const columns = rows.reduce((max, row) => Math.max(max, row.length), 0);
    for (let r = 0; r < Math.min(15, rows.length); r++) {
      const headers = rows[r].map(normalize);
      const id2 = findColumn(headers, ID_HEADERS);
      const grade2 = findColumn(headers, GRADE_HEADERS);
      if (id2 < 0 || grade2 < 0 || id2 === grade2) continue;
      let name2 = findColumn(headers, NAME_HEADERS);
      if (name2 === id2 || name2 === grade2) name2 = -1;
      return { headerRow: r, mapping: { id: id2, name: name2, grade: grade2 }, columns };
    }
    const share = (test) => Array.from({ length: columns }, (_, c) => {
      const cells = rows.map((row) => row[c] ?? "").filter((cell) => cell !== "");
      return cells.length === 0 ? 0 : cells.filter(test).length / cells.length;
    });
    const idShare = share(looksLikeStudentNumber);
    const gradeShare = share((cell) => GRADE_LIKE.test(cell));
    const nameShare = share((cell) => new RegExp("\\p{L}", "u").test(cell) && /[\s,]/.test(cell) && !looksLikeStudentNumber(cell) && !GRADE_LIKE.test(cell));
    const pick = (shares, skip = [], fromRight = false) => {
      let best = -1;
      for (let c = 0; c < shares.length; c++) {
        if (skip.includes(c) || shares[c] < 0.5) continue;
        if (best < 0 || shares[c] > shares[best] || fromRight && shares[c] === shares[best]) best = c;
      }
      return best;
    };
    const id = pick(idShare);
    const grade = pick(gradeShare, [id], true);
    const name = pick(nameShare, [id, grade]);
    return { headerRow: -1, mapping: { id, name, grade }, columns };
  }
  function extractRows(table, headerRow, mapping) {
    const rows = [];
    let ignored = 0;
    if (mapping.id < 0 || mapping.grade < 0) return { rows, ignored };
    for (let r = headerRow + 1; r < table.length; r++) {
      const cells = table[r];
      const studentNumber = (cells[mapping.id] ?? "").trim();
      if (!looksLikeStudentNumber(studentNumber)) {
        ignored++;
        continue;
      }
      rows.push({
        line: r + 1,
        studentNumber,
        key: idKey(studentNumber),
        name: mapping.name >= 0 ? (cells[mapping.name] ?? "").trim() : "",
        rawGrade: (cells[mapping.grade] ?? "").trim()
      });
    }
    return { rows, ignored };
  }

  // extensions/mmsu-gradesheet/src/grade.ts
  var WORDS = { INCOMPLETE: "INC", DROPPED: "DRP", DROP: "DRP", "IN PROGRESS": "IP" };
  function resolveGrade(raw, allowed) {
    const text = raw.trim().replace(/^"|"$/g, "").trim();
    if (text === "" || /^[-–—]+$/.test(text)) return { kind: "blank" };
    const numeric = /^\d+(?:[.,]\d+)?$/.exec(text);
    if (numeric) {
      const value = Number(text.replace(",", ".")).toFixed(2);
      return allowed.includes(value) ? { kind: "grade", value } : { kind: "invalid", reason: `${value} is not a grade the portal offers` };
    }
    const upper = text.toUpperCase().replace(/\s+/g, " ");
    const word = WORDS[upper] ?? upper;
    const match = allowed.find((option) => option.toUpperCase() === word);
    return match ? { kind: "grade", value: match } : { kind: "invalid", reason: `"${text}" is not a grade the portal offers` };
  }

  // extensions/mmsu-gradesheet/src/plan.ts
  function buildPlan(source, portal) {
    const byKey = new Map(portal.map((row) => [row.key, row]));
    const resolved = source.map((row) => {
      const target = byKey.get(row.key);
      return { row, target, grade: resolveGrade(row.rawGrade, target?.options ?? [...ALL_OPTIONS_FALLBACK]) };
    });
    const seen = /* @__PURE__ */ new Map();
    const conflicting = /* @__PURE__ */ new Set();
    for (const { row, grade } of resolved) {
      const value = grade.kind === "grade" ? grade.value : "";
      if (!seen.has(row.key)) seen.set(row.key, value);
      else if (seen.get(row.key) !== value) conflicting.add(row.key);
    }
    const handled = /* @__PURE__ */ new Set();
    const items = [];
    for (const { row, target, grade } of resolved) {
      const base = { source: row, portal: target, nameWarning: !!target && namesDisagree(row.name, target.name) };
      if (conflicting.has(row.key)) {
        items.push({ ...base, status: "duplicate", reason: "listed more than once with different grades" });
        continue;
      }
      if (handled.has(row.key)) continue;
      handled.add(row.key);
      if (!target) items.push({ ...base, status: "not-on-portal", reason: "no student with this number on the portal gradesheet" });
      else if (grade.kind === "blank") items.push({ ...base, status: "blank", current: target.current, reason: "empty grade cell" });
      else if (grade.kind === "invalid") items.push({ ...base, status: "invalid", current: target.current, reason: grade.reason });
      else if (target.locked) items.push({ ...base, status: "locked", current: target.current, reason: "the portal does not let this grade be edited" });
      else if (target.current === grade.value) items.push({ ...base, status: "same", value: grade.value, current: target.current });
      else items.push({ ...base, status: "change", value: grade.value, current: target.current });
    }
    const pasted = new Set(source.map((row) => row.key));
    return { items, portalOnly: portal.filter((row) => !pasted.has(row.key)) };
  }
  var ALL_OPTIONS_FALLBACK = ["1.00", "1.25", "1.50", "1.75", "2.00", "2.25", "2.50", "2.75", "3.00", "4.00", "5.00", "INC", "DRP", "IP"];

  // extensions/mmsu-gradesheet/src/portal.ts
  var NO_GRADE = "0";
  var textOf = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
  function labelled(doc, label) {
    for (const cell of Array.from(doc.querySelectorAll("td"))) {
      if (textOf(cell) === label) return textOf(cell.nextElementSibling);
    }
    return "";
  }
  function readSheet(doc) {
    const form = doc.querySelector('form[action*="/gradesheet/update/"]');
    if (!form) return null;
    const sheetId = /\/gradesheet\/update\/(\d+)/.exec(form.getAttribute("action") ?? "")?.[1];
    const saveButton = form.querySelector('[name="savegradesheet"]');
    const selects = Array.from(form.querySelectorAll('select[name^="grade_"]'));
    if (!sheetId || !saveButton || selects.length === 0) return null;
    const headers = Array.from(form.querySelectorAll("thead td, thead th")).map((cell) => textOf(cell).toLowerCase());
    const column = (label, fallback) => {
      const index = headers.indexOf(label);
      return index >= 0 ? index : fallback;
    };
    const nameAt = column("name", 2);
    const numberAt = column("student number", 3);
    const degreeAt = column("degree", 4);
    const rows = [];
    for (const select of selects) {
      const cells = select.closest("tr")?.children;
      if (!cells) continue;
      const studentNumber = textOf(cells[numberAt]);
      if (studentNumber === "") continue;
      const options = Array.from(select.options).map((option) => option.value).filter((value) => value !== NO_GRADE);
      rows.push({
        key: idKey(studentNumber),
        studentNumber,
        name: textOf(cells[nameAt]),
        degree: textOf(cells[degreeAt]),
        select,
        current: select.value === NO_GRADE ? "" : select.value,
        options,
        locked: select.disabled
      });
    }
    if (rows.length === 0) return null;
    return {
      sheetId,
      course: labelled(doc, "Course"),
      title: textOf(doc.querySelector(".panel-heading strong")) || labelled(doc, "Title"),
      rows,
      saveButton
    };
  }
  function readAlerts(doc) {
    return Array.from(doc.querySelectorAll(".alert, .alert-flash")).map((el) => textOf(el)).filter((text) => text !== "").slice(0, 3);
  }

  // extensions/mmsu-gradesheet/src/panel.ts
  function h(tag, props = {}, ...children) {
    const el = document.createElement(tag);
    if (props.cls) el.className = props.cls;
    if (props.text !== void 0) el.textContent = props.text;
    for (const [name, value] of Object.entries(props.attrs ?? {})) el.setAttribute(name, value);
    for (const [name, handler] of Object.entries(props.on ?? {})) el.addEventListener(name, handler);
    for (const child of children) if (child) el.append(child);
    return el;
  }
  var STYLE = `
:host { all: initial; }
* { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", sans-serif; }
.pill { position: fixed; right: 0; top: 40%; z-index: 2147483000; background: #1d4ed8; color: #fff; border: 0; padding: 10px 8px;
  border-radius: 8px 0 0 8px; cursor: pointer; font-size: 12px; writing-mode: vertical-rl; letter-spacing: .03em; }
.panel { position: fixed; right: 12px; top: 12px; z-index: 2147483001; width: 520px; max-width: calc(100vw - 24px); max-height: calc(100vh - 24px);
  overflow: auto; background: #fff; color: #111827; border: 1px solid #9ca3af; border-radius: 10px; box-shadow: 0 8px 30px rgba(0,0,0,.25);
  font-size: 13px; line-height: 1.4; }
.hidden { display: none !important; }
header { display: flex; justify-content: space-between; align-items: center; gap: 8px; padding: 10px 12px; background: #1e3a8a; color: #fff;
  position: sticky; top: 0; z-index: 1; }
header strong { font-size: 14px; }
section { padding: 10px 12px; border-top: 1px solid #e5e7eb; }
h3 { margin: 0 0 6px; font-size: 12px; text-transform: uppercase; letter-spacing: .05em; color: #4b5563; }
textarea { width: 100%; min-height: 84px; font: 12px ui-monospace, Consolas, monospace; padding: 6px; border: 1px solid #9ca3af; border-radius: 6px; resize: vertical; }
select { max-width: 100%; padding: 3px; font-size: 12px; }
label.map { display: inline-flex; flex-direction: column; gap: 2px; margin-right: 10px; font-size: 12px; color: #374151; }
button { font-size: 13px; padding: 6px 10px; border-radius: 6px; border: 1px solid #6b7280; background: #f3f4f6; color: #111827; cursor: pointer; }
button.primary { background: #1d4ed8; border-color: #1d4ed8; color: #fff; }
button.danger { background: #b91c1c; border-color: #b91c1c; color: #fff; }
button:disabled { opacity: .5; cursor: not-allowed; }
.actions { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 8px; }
.chips { display: flex; flex-wrap: wrap; gap: 6px; margin: 6px 0; }
.chip { padding: 2px 8px; border-radius: 99px; background: #e5e7eb; font-size: 12px; }
.chip.bad { background: #fee2e2; color: #7f1d1d; } .chip.good { background: #dcfce7; color: #14532d; } .chip.warn { background: #fef3c7; color: #78350f; }
table { width: 100%; border-collapse: collapse; font-size: 12px; }
th, td { text-align: left; padding: 3px 5px; border-bottom: 1px solid #e5e7eb; vertical-align: top; }
th { position: sticky; top: 0; background: #f9fafb; }
.scroll { max-height: 280px; overflow: auto; border: 1px solid #e5e7eb; border-radius: 6px; }
.note { color: #4b5563; } .note.bad { color: #991b1b; } .note.warn { color: #92400e; }
.banner { padding: 8px 10px; border-radius: 6px; margin: 4px 0; }
.banner.ok { background: #dcfce7; color: #14532d; } .banner.bad { background: #fee2e2; color: #7f1d1d; } .banner.info { background: #dbeafe; color: #1e3a8a; }
.mono { font-family: ui-monospace, Consolas, monospace; }
`;
  var STATUS_NOTE = {
    change: "will change",
    same: "already set",
    blank: "empty cell \u2014 left alone",
    invalid: "",
    duplicate: "",
    "not-on-portal": "",
    locked: ""
  };
  var Panel = class {
    root;
    panel;
    top;
    below;
    area;
    pill;
    pasteSection;
    /** null until the Vantage server has answered; the panel does nothing but show this while access is not allowed. */
    access = null;
    checkingAccess = false;
    table = [];
    detected = { headerRow: -1, mapping: { id: -1, name: -1, grade: -1 }, columns: 0 };
    plan = null;
    ignored = 0;
    checked = /* @__PURE__ */ new Set();
    message = null;
    verification = null;
    pendingJob = null;
    sheet;
    constructor(sheet) {
      this.sheet = sheet;
      const host = h("div", { attrs: { id: "vantage-mmsu-push" } });
      this.root = host.attachShadow({ mode: "open" });
      this.pill = h("button", { cls: "pill", text: "Vantage grade push", on: { click: () => this.toggle(true) } });
      this.top = h("div");
      this.below = h("div");
      this.area = h("textarea", { attrs: { placeholder: "Copy the table from Excel or Google Sheets (with its header row) and paste it here", "aria-label": "Pasted table" } });
      this.area.addEventListener("input", () => this.onPaste(this.area.value));
      this.pasteSection = h("section", {}, h("h3", { text: "1. Paste your sheet" }), this.area);
      const close = h("button", { text: "Hide", on: { click: () => this.toggle(false) } });
      this.panel = h(
        "div",
        { cls: "panel hidden", attrs: { role: "dialog", "aria-label": "Vantage grade push" } },
        h("header", {}, h("strong", { text: "Vantage grade push" }), close),
        this.top,
        this.pasteSection,
        this.below
      );
      this.root.append(h("style", { text: STYLE }), this.pill, this.panel);
      document.body.append(host);
    }
    toggle(open) {
      this.panel.classList.toggle("hidden", !open);
      this.pill.classList.toggle("hidden", open);
    }
    /** Called once on load: shows a pending job's result if the page was just saved. */
    async start() {
      this.checkingAccess = true;
      this.render();
      this.access = await requestAccess();
      this.checkingAccess = false;
      if (!this.access.allowed) {
        this.render();
        return;
      }
      const job = await loadJob(this.sheet.sheetId);
      if (job?.stage === "saving" && Date.now() - job.createdAt <= AUTO_VERIFY_MS) {
        this.verification = { job, result: verifyJob(job, this.sheet), alerts: readAlerts(document) };
        this.toggle(true);
      } else if (job) {
        this.pendingJob = job;
      }
      this.render();
    }
    // ---- state changes -------------------------------------------------------------------------
    onPaste(text) {
      this.message = null;
      this.table = parseDelimited(text);
      this.detected = detectMapping(this.table);
      this.recompute(true);
    }
    setMapping(mapping) {
      this.detected = { ...this.detected, mapping };
      this.recompute(true);
    }
    recompute(resetChecks) {
      const { rows, ignored } = extractRows(this.table, this.detected.headerRow, this.detected.mapping);
      this.ignored = ignored;
      this.plan = rows.length > 0 ? buildPlan(rows, this.sheet.rows) : null;
      if (resetChecks && this.plan) {
        this.checked = new Set(this.plan.items.filter((i) => i.status === "change" && !i.nameWarning).map((i) => i.source.key));
      }
      this.render();
    }
    async fill(save) {
      if (!this.plan) return;
      const selected = this.plan.items.filter((i) => i.status === "change" && this.checked.has(i.source.key));
      if (selected.length === 0) return;
      if (save && !window.confirm(`Set ${selected.length} grade${selected.length === 1 ? "" : "s"} and press "Save Gradesheet" on this page?`)) return;
      const before = {};
      for (const row of this.sheet.rows) before[row.key] = row.current;
      const { applied, failed } = applyChanges(selected);
      if (failed.length > 0) {
        this.message = { kind: "bad", text: `${failed.length} grade(s) could not be set (${failed.map((f) => f.source.studentNumber).join(", ")}). Nothing was saved.` };
        this.render();
        return;
      }
      const expected = this.plan.items.filter((i) => i.value !== void 0 && (i.status === "same" || i.status === "change" && this.checked.has(i.source.key))).map((i) => ({ key: i.source.key, studentNumber: i.portal?.studentNumber ?? i.source.studentNumber, name: i.portal?.name ?? i.source.name, value: i.value }));
      const job = { sheetId: this.sheet.sheetId, createdAt: Date.now(), stage: save ? "saving" : "filled", expected, before };
      await saveJob(job);
      if (save) {
        this.message = { kind: "info", text: `Saving ${applied} grade(s)\u2026` };
        this.render();
        this.sheet.saveButton.click();
        return;
      }
      this.message = { kind: "ok", text: `Filled ${applied} grade(s). Review them, then press the portal's "Save Gradesheet". After the page reloads, open this panel and press "Check the portal".` };
      this.render();
    }
    checkPortal() {
      const job = this.pendingJob;
      if (!job) return;
      this.verification = { job, result: verifyJob(job, readSheet(document) ?? this.sheet), alerts: readAlerts(document) };
      this.pendingJob = null;
      this.render();
    }
    async finish() {
      await clearJob(this.sheet.sheetId);
      this.verification = null;
      this.pendingJob = null;
      this.render();
    }
    // ---- rendering -----------------------------------------------------------------------------
    async recheckAccess() {
      this.checkingAccess = true;
      this.render();
      this.access = await requestAccess(true);
      this.checkingAccess = false;
      if (this.access.allowed) await this.start();
      else this.render();
    }
    /** The gate: shown instead of the tool until the Vantage server says this person may use it. */
    renderGate() {
      const access = this.access;
      if (this.checkingAccess || !access) return [h("section", {}, h("div", { cls: "banner info", text: "Checking your Vantage access\u2026" }))];
      if (access.allowed) return [];
      const { title, text } = describeDenied(access);
      return [h(
        "section",
        {},
        h("div", { cls: "banner bad" }, h("strong", { text: title }), h("div", { text })),
        h(
          "div",
          { cls: "actions" },
          h("button", { cls: "primary", text: "Check again", on: { click: () => void this.recheckAccess() } }),
          access.appUrl ? h("button", { text: "Open Vantage", on: { click: () => window.open(access.appUrl, "_blank", "noopener") } }) : null
        )
      )];
    }
    render() {
      const gated = !this.access?.allowed;
      this.pasteSection.classList.toggle("hidden", gated);
      if (gated) {
        this.top.replaceChildren(...this.renderGate());
        this.below.replaceChildren();
        return;
      }
      this.top.replaceChildren(
        h("section", {}, h("div", { cls: "note", text: `Signed in to Vantage as ${this.access?.allowed ? this.access.name : ""}` }), h("div", { text: `${this.sheet.course || "Gradesheet"} \u2014 ${this.sheet.title}` }), h("div", { cls: "note", text: `${this.sheet.rows.length} students on this portal gradesheet` })),
        ...[this.renderMessage(), this.renderVerification(), this.renderPending()].filter((n) => n !== null)
      );
      this.below.replaceChildren(...[this.renderMapping(), this.renderPreview()].filter((n) => n !== null));
    }
    renderMessage() {
      return this.message ? h("section", {}, h("div", { cls: `banner ${this.message.kind}`, text: this.message.text })) : null;
    }
    renderPending() {
      if (!this.pendingJob || this.verification) return null;
      return h(
        "section",
        {},
        h("div", { cls: "banner info", text: `Earlier you filled ${this.pendingJob.expected.length} grade(s) on this gradesheet.` }),
        h(
          "div",
          { cls: "actions" },
          h("button", { cls: "primary", text: "Check the portal", on: { click: () => this.checkPortal() } }),
          h("button", { text: "Dismiss", on: { click: () => void this.finish() } })
        )
      );
    }
    renderVerification() {
      if (!this.verification) return null;
      const { result, alerts } = this.verification;
      const total = result.items.length;
      const bad = result.items.filter((i) => i.status !== "match");
      const ok = bad.length === 0 && result.unexpected.length === 0;
      return h(
        "section",
        {},
        h("h3", { text: "Portal vs your sheet" }),
        h("div", { cls: `banner ${ok ? "ok" : "bad"}`, text: ok ? `All ${total} grade${total === 1 ? "" : "s"} on the portal match your sheet.` : `${result.matched} of ${total} match. ${bad.length} differ or are missing${result.unexpected.length ? `, and ${result.unexpected.length} other grade(s) changed that you did not ask for` : ""}.` }),
        ...alerts.map((text) => h("div", { cls: "note", text: `Portal message: ${text}` })),
        bad.length > 0 ? h("div", { cls: "scroll" }, h(
          "table",
          {},
          h("thead", {}, h("tr", {}, h("th", { text: "Student" }), h("th", { text: "Sheet" }), h("th", { text: "Portal" }))),
          h("tbody", {}, ...bad.map((i) => h(
            "tr",
            {},
            h("td", {}, h("span", { cls: "mono", text: i.studentNumber }), ` ${i.name}`),
            h("td", { text: i.expected }),
            h("td", { cls: "note bad", text: i.status === "missing" ? "not on the portal" : i.actual || "---" })
          )))
        )) : null,
        result.unexpected.length > 0 ? h("div", { cls: "scroll" }, h(
          "table",
          {},
          h("thead", {}, h("tr", {}, h("th", { text: "Changed without being asked" }), h("th", { text: "Before" }), h("th", { text: "Now" }))),
          h("tbody", {}, ...result.unexpected.map((u) => h(
            "tr",
            {},
            h("td", {}, h("span", { cls: "mono", text: u.studentNumber }), ` ${u.name}`),
            h("td", { text: u.before || "---" }),
            h("td", { text: u.after || "---" })
          )))
        )) : null,
        h("div", { cls: "actions" }, h("button", { cls: "primary", text: "Done", on: { click: () => void this.finish() } }))
      );
    }
    renderMapping() {
      if (this.table.length === 0) return null;
      const headers = this.detected.headerRow >= 0 ? this.table[this.detected.headerRow] : [];
      const select = (label, field, optional) => {
        const el = h("select", { attrs: { "aria-label": label } });
        el.append(h("option", { text: optional ? "(none)" : "\u2014 choose \u2014", attrs: { value: "-1" } }));
        for (let c = 0; c < this.detected.columns; c++) {
          const sample = this.table[this.detected.headerRow + 1]?.[c] ?? "";
          el.append(h("option", { text: `${c + 1}: ${headers[c] || sample || "(empty)"}`.slice(0, 40), attrs: { value: String(c) } }));
        }
        el.value = String(this.detected.mapping[field]);
        el.addEventListener("change", () => this.setMapping({ ...this.detected.mapping, [field]: Number(el.value) }));
        return h("label", { cls: "map" }, label, el);
      };
      return h(
        "section",
        {},
        h("h3", { text: "2. Columns" }),
        select("Student number", "id", false),
        select("Name (optional)", "name", true),
        select("Final grade", "grade", false),
        this.detected.headerRow < 0 ? h("div", { cls: "note", text: "No header row found \u2014 columns were guessed from the cells." }) : null
      );
    }
    renderPreview() {
      if (this.table.length === 0) return null;
      if (!this.plan) return h("section", {}, h("h3", { text: "3. Review" }), h("div", { cls: "banner bad", text: "No student rows found. Check the columns above (the student number column needs numbers like 23-050573)." }));
      const { items, portalOnly } = this.plan;
      const count = (status) => items.filter((i) => i.status === status).length;
      const problems = items.filter((i) => ["invalid", "duplicate", "not-on-portal", "locked"].includes(i.status)).length;
      const selected = items.filter((i) => i.status === "change" && this.checked.has(i.source.key)).length;
      const chips = h(
        "div",
        { cls: "chips" },
        h("span", { cls: "chip good", text: `${count("change")} to change` }),
        h("span", { cls: "chip", text: `${count("same")} already set` }),
        problems ? h("span", { cls: "chip bad", text: `${problems} cannot be applied` }) : null,
        portalOnly.length ? h("span", { cls: "chip warn", text: `${portalOnly.length} on the portal, not in your paste` }) : null,
        this.ignored ? h("span", { cls: "chip", text: `${this.ignored} non-student line(s) skipped` }) : null
      );
      const rows = items.map((item) => {
        const change = item.status === "change";
        const box = h("input", { attrs: { type: "checkbox", "aria-label": `Apply ${item.source.studentNumber}` } });
        box.checked = this.checked.has(item.source.key);
        box.disabled = !change;
        box.addEventListener("change", () => {
          if (box.checked) this.checked.add(item.source.key);
          else this.checked.delete(item.source.key);
          this.render();
        });
        const bad = ["invalid", "duplicate", "not-on-portal", "locked"].includes(item.status);
        const note = item.nameWarning ? `Name differs \u2014 portal has "${item.portal?.name}". Check before applying.` : bad ? item.reason ?? "" : STATUS_NOTE[item.status];
        return h(
          "tr",
          {},
          h("td", {}, change ? box : null),
          h("td", {}, h("span", { cls: "mono", text: item.source.studentNumber }), h("div", { cls: "note", text: item.source.name || item.portal?.name || "" })),
          h("td", { text: change ? `${item.current || "---"} \u2192 ${item.value}` : item.status === "same" ? item.value ?? "" : item.source.rawGrade || "\u2014" }),
          h("td", { cls: `note ${bad ? "bad" : item.nameWarning ? "warn" : ""}`, text: note })
        );
      });
      return h(
        "section",
        {},
        h("h3", { text: "3. Review" }),
        chips,
        h("div", { cls: "scroll" }, h(
          "table",
          {},
          h("thead", {}, h("tr", {}, h("th", { text: "" }), h("th", { text: "Student" }), h("th", { text: "Grade" }), h("th", { text: "Note" }))),
          h("tbody", {}, ...rows)
        )),
        h(
          "div",
          { cls: "actions" },
          h("button", { text: `Fill ${selected} grade${selected === 1 ? "" : "s"} (don't save)`, attrs: selected ? {} : { disabled: "" }, on: { click: () => void this.fill(false) } }),
          h("button", { cls: "primary", text: `Fill and save gradesheet`, attrs: selected ? {} : { disabled: "" }, on: { click: () => void this.fill(true) } })
        ),
        h("div", { cls: "note", text: "Students are matched by student number only. Nothing is changed for students you did not paste, and the portal's Remove and Reset buttons are never used." })
      );
    }
  };
  async function mountPanel() {
    const sheet = readSheet(document);
    if (!sheet) return;
    await new Panel(sheet).start();
  }

  // extensions/mmsu-gradesheet/src/content.ts
  void mountPanel();
})();
