Vantage Portal Insert Grade
=======================

Install (Chrome or Edge):
1. Extract this zip into a folder you will keep (the browser reads the extension from it).
2. Open chrome://extensions (Edge: edge://extensions) and turn on "Developer mode".
3. Click "Load unpacked" and choose the extracted folder.

Access: you must be signed in to Vantage in this same browser, and an administrator must have allowed "Portal Insert Grade" for you (then switch it on in your Vantage Profile).

Use: open a class gradesheet on my.mmsu.edu.ph (Grade Sheet > Edit). A "Portal Insert Grade" tab appears
on the right edge of the page. Clicking the extension's toolbar icon opens the portal's Grade Sheet list in a new tab. Full instructions are on the Vantage "Portal Insert Grade" page.
